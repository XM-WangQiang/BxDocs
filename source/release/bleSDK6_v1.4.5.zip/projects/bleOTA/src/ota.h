#ifndef _OTA_H_
#define _OTA_H_

#include <stdbool.h>

void ota_init(void);
void ota_proc(void);
bool is_ota_proc(void);
#endif  
