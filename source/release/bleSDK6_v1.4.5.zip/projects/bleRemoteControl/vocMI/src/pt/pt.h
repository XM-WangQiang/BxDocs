/**
 * @file pt.h
 */
#ifndef PT_H
#define PT_H

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>

#include "pt_def.h"
#include "pt_log.h"
#include "pt_list.h"

#define pt_calloc  calloc
#define pt_malloc  malloc
#define pt_free    free
#define pt_memcpy  memcpy
#define pt_snprintf snprintf

#define pt_assert assert

#endif /* PT_H */

