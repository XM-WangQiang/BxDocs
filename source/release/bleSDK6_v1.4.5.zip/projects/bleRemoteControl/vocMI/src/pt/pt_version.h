/**
 * @file pt_version.h
 */
#ifndef PT_VERSION_H
#define PT_VERSION_H

#define CHIP_MODEL      "B66"
#define SDK_VER         "1P4P1"
#define HW_VERSION      "1P0"

#define PROJ_NAME       "RCU"
#define PROJ_VERSION    "V001"
#define PROJ_BUILD_DATE __DATE__
#define PROJ_BUILD_TIME __TIME__


#endif /* PT_VERSION_H */
